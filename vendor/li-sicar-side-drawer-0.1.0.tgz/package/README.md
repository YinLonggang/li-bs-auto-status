---
status: stable
owner: platform
updated: 2026-09-29
---

# SPA shared side drawer

`@li-sicar/side-drawer` owns the single React drawer implementation extracted from GPC. It contains presentation, modal keyboard/focus behavior and a per-document body scroll lock only. It performs no network I/O, authorization, persistence or business-specific dirty checking.

## Contract

```tsx
import SideDrawer, { type SideDrawerProps } from '@li-sicar/side-drawer';

<SideDrawer
  open={open}
  title="Edit"
  subtitle="Optional description"
  size="lg"
  saving={saving}
  onClose={requestClose}
  footer={<button disabled={saving} onClick={save}>Save</button>}
>
  {form}
</SideDrawer>
```

- `open`, `title: string`, `children` and `onClose: () => void` are required. `subtitle`, `footer` and `saving` are optional. Named and default component exports are equivalent.
- Sizes are `md` (520px), `lg` (640px, default), `xl` (760px) and `wide` (1180px / 1280px). The original GPC responsive Tailwind classes, labels and DOM structure are retained; panels fill the viewport below the host's `lg` breakpoint.
- `className` appends panel classes; `overlayClassName`, `bodyClassName`, and `footerClassName` append to those slots. Host CSS controls theme tokens. This package does not add a portal or bundle global CSS.
- `onClose` is a request, not a forced state change. The host decides whether to confirm/discard dirty data, and controls `open`. `saving` blocks the built-in close button, backdrop and Escape; the host must also disable its own cancel/save actions as appropriate.
- Only the topmost drawer handles close requests and traps focus. Nested and parallel drawers share one body lock until the last closes, including non-LIFO unmounts. Opening focuses the first enabled control (normally close), or the panel if no controls are available. Closing restores the appropriate connected opener. Title and subtitle ARIA IDs are unique per React instance.
- Child widgets may consume Escape before the drawer sees it. Focusable content belongs inside the panel; independent portaled focus scopes/modal libraries are not registered in this drawer stack. Portal-based selectors that keep focus on their in-panel input are compatible.
- `resolveDrawerTabTarget` remains exported for GPC's compatibility import. Do not maintain another implementation in a SPA.

## Host styling and distribution

The host must provide the existing GPC semantic Tailwind tokens (`surface`, `surface-strong`, `ink`, `ink-muted`, `outline`) and `btn btn--ghost` styles, or map them in host CSS. Include the installed package in Tailwind's content scan so responsive/arbitrary-value utilities survive production builds:

```js
content: [
  './index.html', './src/**/*.{ts,tsx}',
  './node_modules/@li-sicar/side-drawer/dist/**/*.{js,mjs}',
]
```

From the root checkout with Node.js 22, explicitly name every SPA to update:

```bash
node tools/frontend/sync-side-drawer.mjs li-sicar-gpc
node tools/frontend/sync-side-drawer.mjs li-bs-auto-status
# Multiple targets receive the same archive; no target is implicit.
node tools/frontend/sync-side-drawer.mjs li-sicar-gpc li-bs-auto-status
```

The script runs package tests/type-check/build, packs the versioned library, copies it to each selected SPA's `vendor/`, and updates that SPA's `package.json` and lockfile. Commit the archive and both manifests together; independent SPA clones can then use `npm ci` without the root checkout. React is a peer dependency. `main`, `types`, and `exports.default` support the existing Node 22 CommonJS/ESM and TypeScript harnesses.

For upgrades, change this package and increment its version before distributing. Replacing a same-version archive with different bytes is rejected. Run affected SPA type-check/build and drawer interaction tests after distribution. Remove superseded vendor archives only when no manifest or lockfile refers to them.

## Package checks

```bash
npm --prefix libs/side-drawer ci
npm --prefix libs/side-drawer test
npm --prefix libs/side-drawer run type-check
npm --prefix libs/side-drawer run build
```

The jsdom behavior suite covers close guards, stack ownership, focus recovery, hidden controls, unique ARIA references, non-LIFO scroll-lock cleanup, synchronous close and React StrictMode. Real-browser Tab navigation remains covered by GPC's `test:side-drawer-browser`; themes and responsive visuals must be checked in each styled host.
